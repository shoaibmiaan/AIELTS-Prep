// placeholder
export const callGemini = () => { throw new Error('callGemini is not implemented'); };
