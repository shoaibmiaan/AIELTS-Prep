export const writingPrompts = [
  {
    "id": 1,
    "type": "task1",
    "subtype": "academic",
    "task": "The table displays data on education rates across three regions. Summarise the data and compare the trends."
  },
  {
    "id": 2,
    "type": "task1",
    "subtype": "academic",
    "task": "The diagram illustrates the process of generating electricity from solar panels. Describe the process."
  },
  {
    "id": 3,
    "type": "task1",
    "subtype": "academic",
    "task": "The diagram illustrates the process of making cheese. Describe the process."
  },
  {
    "id": 4,
    "type": "task1",
    "subtype": "academic",
    "task": "The diagram illustrates the process of recycling plastic bottles. Describe the process."
  },
  {
    "id": 5,
    "type": "task1",
    "subtype": "academic",
    "task": "The diagram illustrates the process of generating electricity from solar panels. Describe the process."
  },
  {
    "id": 6,
    "type": "task1",
    "subtype": "academic",
    "task": "The diagram illustrates the process of generating electricity from solar panels. Describe the process."
  },
  {
    "id": 7,
    "type": "task1",
    "subtype": "academic",
    "task": "The diagram illustrates the process of generating electricity from solar panels. Describe the process."
  },
  {
    "id": 8,
    "type": "task1",
    "subtype": "academic",
    "task": "The chart shows the percentage of renewable energy usage from 2000 to 2005. Summarise the information."
  },
  {
    "id": 9,
    "type": "task1",
    "subtype": "academic",
    "task": "The diagram illustrates the process of recycling plastic bottles. Describe the process."
  },
  {
    "id": 10,
    "type": "task1",
    "subtype": "academic",
    "task": "The chart shows the percentage of renewable energy usage from 2010 to 2020. Summarise the information."
  },
  {
    "id": 11,
    "type": "task1",
    "subtype": "academic",
    "task": "The table displays data on consumer spending across three regions. Summarise the data and compare the trends."
  },
  {
    "id": 12,
    "type": "task1",
    "subtype": "academic",
    "task": "The table displays data on consumer spending across four major cities. Summarise the data and compare the trends."
  },
  {
    "id": 13,
    "type": "task1",
    "subtype": "academic",
    "task": "The chart shows the percentage of households with Internet access from 2010 to 2020. Summarise the information."
  },
  {
    "id": 14,
    "type": "task1",
    "subtype": "academic",
    "task": "The table displays data on education rates across five countries. Summarise the data and compare the trends."
  },
  {
    "id": 15,
    "type": "task1",
    "subtype": "academic",
    "task": "The diagram illustrates the process of making cheese. Describe the process."
  },
  {
    "id": 16,
    "type": "task1",
    "subtype": "academic",
    "task": "The table displays data on education rates across three regions. Summarise the data and compare the trends."
  },
  {
    "id": 17,
    "type": "task1",
    "subtype": "academic",
    "task": "The table displays data on consumer spending across three regions. Summarise the data and compare the trends."
  },
  {
    "id": 18,
    "type": "task1",
    "subtype": "academic",
    "task": "The table displays data on education rates across four major cities. Summarise the data and compare the trends."
  },
  {
    "id": 19,
    "type": "task1",
    "subtype": "academic",
    "task": "The table displays data on unemployment figures across three regions. Summarise the data and compare the trends."
  },
  {
    "id": 20,
    "type": "task1",
    "subtype": "academic",
    "task": "The diagram illustrates the process of recycling plastic bottles. Describe the process."
  },
  {
    "id": 21,
    "type": "task1",
    "subtype": "academic",
    "task": "The chart shows the percentage of students enrolled in universities from 1995 to 2010. Summarise the information."
  },
  {
    "id": 22,
    "type": "task1",
    "subtype": "academic",
    "task": "The chart shows the percentage of households with Internet access from 2000 to 2020. Summarise the information."
  },
  {
    "id": 23,
    "type": "task1",
    "subtype": "academic",
    "task": "The chart shows the percentage of households with Internet access from 2010 to 2010. Summarise the information."
  },
  {
    "id": 24,
    "type": "task1",
    "subtype": "academic",
    "task": "The chart shows the percentage of households with Internet access from 2000 to 2005. Summarise the information."
  },
  {
    "id": 25,
    "type": "task1",
    "subtype": "academic",
    "task": "The diagram illustrates the process of recycling plastic bottles. Describe the process."
  },
  {
    "id": 26,
    "type": "task1",
    "subtype": "academic",
    "task": "The table displays data on unemployment figures across five countries. Summarise the data and compare the trends."
  },
  {
    "id": 27,
    "type": "task1",
    "subtype": "academic",
    "task": "The diagram illustrates the process of making cheese. Describe the process."
  },
  {
    "id": 28,
    "type": "task1",
    "subtype": "academic",
    "task": "The table displays data on education rates across three regions. Summarise the data and compare the trends."
  },
  {
    "id": 29,
    "type": "task1",
    "subtype": "academic",
    "task": "The chart shows the percentage of students enrolled in universities from 2000 to 2010. Summarise the information."
  },
  {
    "id": 30,
    "type": "task1",
    "subtype": "academic",
    "task": "The diagram illustrates the process of making cheese. Describe the process."
  },
  {
    "id": 31,
    "type": "task1",
    "subtype": "academic",
    "task": "The chart shows the percentage of students enrolled in universities from 2010 to 2010. Summarise the information."
  },
  {
    "id": 32,
    "type": "task1",
    "subtype": "academic",
    "task": "The chart shows the percentage of students enrolled in universities from 2000 to 2020. Summarise the information."
  },
  {
    "id": 33,
    "type": "task1",
    "subtype": "academic",
    "task": "The diagram illustrates the process of making cheese. Describe the process."
  },
  {
    "id": 34,
    "type": "task1",
    "subtype": "academic",
    "task": "The table displays data on consumer spending across three regions. Summarise the data and compare the trends."
  },
  {
    "id": 35,
    "type": "task1",
    "subtype": "academic",
    "task": "The diagram illustrates the process of making cheese. Describe the process."
  },
  {
    "id": 36,
    "type": "task1",
    "subtype": "academic",
    "task": "The diagram illustrates the process of generating electricity from solar panels. Describe the process."
  },
  {
    "id": 37,
    "type": "task1",
    "subtype": "academic",
    "task": "The diagram illustrates the process of generating electricity from solar panels. Describe the process."
  },
  {
    "id": 38,
    "type": "task1",
    "subtype": "academic",
    "task": "The table displays data on unemployment figures across four major cities. Summarise the data and compare the trends."
  },
  {
    "id": 39,
    "type": "task1",
    "subtype": "academic",
    "task": "The chart shows the percentage of renewable energy usage from 1995 to 2020. Summarise the information."
  },
  {
    "id": 40,
    "type": "task1",
    "subtype": "academic",
    "task": "The diagram illustrates the process of generating electricity from solar panels. Describe the process."
  },
  {
    "id": 41,
    "type": "task1",
    "subtype": "academic",
    "task": "The chart shows the percentage of renewable energy usage from 1995 to 2020. Summarise the information."
  },
  {
    "id": 42,
    "type": "task1",
    "subtype": "academic",
    "task": "The chart shows the percentage of students enrolled in universities from 2010 to 2020. Summarise the information."
  },
  {
    "id": 43,
    "type": "task1",
    "subtype": "academic",
    "task": "The chart shows the percentage of renewable energy usage from 2000 to 2005. Summarise the information."
  },
  {
    "id": 44,
    "type": "task1",
    "subtype": "academic",
    "task": "The chart shows the percentage of students enrolled in universities from 2000 to 2010. Summarise the information."
  },
  {
    "id": 45,
    "type": "task1",
    "subtype": "academic",
    "task": "The diagram illustrates the process of recycling plastic bottles. Describe the process."
  },
  {
    "id": 46,
    "type": "task1",
    "subtype": "academic",
    "task": "The diagram illustrates the process of generating electricity from solar panels. Describe the process."
  },
  {
    "id": 47,
    "type": "task1",
    "subtype": "academic",
    "task": "The chart shows the percentage of households with Internet access from 1995 to 2005. Summarise the information."
  },
  {
    "id": 48,
    "type": "task1",
    "subtype": "academic",
    "task": "The table displays data on education rates across three regions. Summarise the data and compare the trends."
  },
  {
    "id": 49,
    "type": "task1",
    "subtype": "academic",
    "task": "The diagram illustrates the process of recycling plastic bottles. Describe the process."
  },
  {
    "id": 50,
    "type": "task1",
    "subtype": "academic",
    "task": "The chart shows the percentage of students enrolled in universities from 1995 to 2020. Summarise the information."
  },
  {
    "id": 51,
    "type": "task1",
    "subtype": "general",
    "task": "You want to book a room. Write a letter to your your manager giving details and asking for help."
  },
  {
    "id": 52,
    "type": "task1",
    "subtype": "general",
    "task": "You want to book a room. Write a letter to your your landlord giving details and asking for help."
  },
  {
    "id": 53,
    "type": "task1",
    "subtype": "general",
    "task": "You have recently lost your luggage. Write a letter to your landlord explaining the situation and your request."
  },
  {
    "id": 54,
    "type": "task1",
    "subtype": "general",
    "task": "You borrowed households with Internet access from a friend and it got damaged. Write a letter to explain and offer compensation."
  },
  {
    "id": 55,
    "type": "task1",
    "subtype": "general",
    "task": "You borrowed renewable energy usage from a friend and it got damaged. Write a letter to explain and offer compensation."
  },
  {
    "id": 56,
    "type": "task1",
    "subtype": "general",
    "task": "You have recently moved to a new city. Write a letter to your friend explaining the situation and your request."
  },
  {
    "id": 57,
    "type": "task1",
    "subtype": "general",
    "task": "You borrowed renewable energy usage from a friend and it got damaged. Write a letter to explain and offer compensation."
  },
  {
    "id": 58,
    "type": "task1",
    "subtype": "general",
    "task": "You want to apply for a loan. Write a letter to your your landlord giving details and asking for help."
  },
  {
    "id": 59,
    "type": "task1",
    "subtype": "general",
    "task": "You have recently lost your luggage. Write a letter to your friend explaining the situation and your request."
  },
  {
    "id": 60,
    "type": "task1",
    "subtype": "general",
    "task": "You want to organize an event. Write a letter to your your manager giving details and asking for help."
  },
  {
    "id": 61,
    "type": "task1",
    "subtype": "general",
    "task": "You want to organize an event. Write a letter to your your manager giving details and asking for help."
  },
  {
    "id": 62,
    "type": "task1",
    "subtype": "general",
    "task": "You want to organize an event. Write a letter to your your manager giving details and asking for help."
  },
  {
    "id": 63,
    "type": "task1",
    "subtype": "general",
    "task": "You have recently moved to a new city. Write a letter to your manager explaining the situation and your request."
  },
  {
    "id": 64,
    "type": "task1",
    "subtype": "general",
    "task": "You want to book a room. Write a letter to your your friend giving details and asking for help."
  },
  {
    "id": 65,
    "type": "task1",
    "subtype": "general",
    "task": "You have recently changed your phone number. Write a letter to your friend explaining the situation and your request."
  },
  {
    "id": 66,
    "type": "task1",
    "subtype": "general",
    "task": "You want to organize an event. Write a letter to your your landlord giving details and asking for help."
  },
  {
    "id": 67,
    "type": "task1",
    "subtype": "general",
    "task": "You want to organize an event. Write a letter to your your landlord giving details and asking for help."
  },
  {
    "id": 68,
    "type": "task1",
    "subtype": "general",
    "task": "You want to organize an event. Write a letter to your your landlord giving details and asking for help."
  },
  {
    "id": 69,
    "type": "task1",
    "subtype": "general",
    "task": "You borrowed households with Internet access from a friend and it got damaged. Write a letter to explain and offer compensation."
  },
  {
    "id": 70,
    "type": "task1",
    "subtype": "general",
    "task": "You want to apply for a loan. Write a letter to your your landlord giving details and asking for help."
  },
  {
    "id": 71,
    "type": "task1",
    "subtype": "general",
    "task": "You borrowed students enrolled in universities from a friend and it got damaged. Write a letter to explain and offer compensation."
  },
  {
    "id": 72,
    "type": "task1",
    "subtype": "general",
    "task": "You want to organize an event. Write a letter to your your friend giving details and asking for help."
  },
  {
    "id": 73,
    "type": "task1",
    "subtype": "general",
    "task": "You borrowed students enrolled in universities from a friend and it got damaged. Write a letter to explain and offer compensation."
  },
  {
    "id": 74,
    "type": "task1",
    "subtype": "general",
    "task": "You want to apply for a loan. Write a letter to your your landlord giving details and asking for help."
  },
  {
    "id": 75,
    "type": "task1",
    "subtype": "general",
    "task": "You want to book a room. Write a letter to your your manager giving details and asking for help."
  },
  {
    "id": 76,
    "type": "task1",
    "subtype": "general",
    "task": "You want to book a room. Write a letter to your your friend giving details and asking for help."
  },
  {
    "id": 77,
    "type": "task1",
    "subtype": "general",
    "task": "You have recently changed your phone number. Write a letter to your manager explaining the situation and your request."
  },
  {
    "id": 78,
    "type": "task1",
    "subtype": "general",
    "task": "You borrowed households with Internet access from a friend and it got damaged. Write a letter to explain and offer compensation."
  },
  {
    "id": 79,
    "type": "task1",
    "subtype": "general",
    "task": "You want to apply for a loan. Write a letter to your your friend giving details and asking for help."
  },
  {
    "id": 80,
    "type": "task1",
    "subtype": "general",
    "task": "You have recently changed your phone number. Write a letter to your landlord explaining the situation and your request."
  },
  {
    "id": 81,
    "type": "task1",
    "subtype": "general",
    "task": "You have recently changed your phone number. Write a letter to your manager explaining the situation and your request."
  },
  {
    "id": 82,
    "type": "task1",
    "subtype": "general",
    "task": "You have recently moved to a new city. Write a letter to your friend explaining the situation and your request."
  },
  {
    "id": 83,
    "type": "task1",
    "subtype": "general",
    "task": "You borrowed households with Internet access from a friend and it got damaged. Write a letter to explain and offer compensation."
  },
  {
    "id": 84,
    "type": "task1",
    "subtype": "general",
    "task": "You want to book a room. Write a letter to your your landlord giving details and asking for help."
  },
  {
    "id": 85,
    "type": "task1",
    "subtype": "general",
    "task": "You want to organize an event. Write a letter to your your landlord giving details and asking for help."
  },
  {
    "id": 86,
    "type": "task1",
    "subtype": "general",
    "task": "You have recently changed your phone number. Write a letter to your manager explaining the situation and your request."
  },
  {
    "id": 87,
    "type": "task1",
    "subtype": "general",
    "task": "You borrowed renewable energy usage from a friend and it got damaged. Write a letter to explain and offer compensation."
  },
  {
    "id": 88,
    "type": "task1",
    "subtype": "general",
    "task": "You borrowed students enrolled in universities from a friend and it got damaged. Write a letter to explain and offer compensation."
  },
  {
    "id": 89,
    "type": "task1",
    "subtype": "general",
    "task": "You have recently lost your luggage. Write a letter to your manager explaining the situation and your request."
  },
  {
    "id": 90,
    "type": "task1",
    "subtype": "general",
    "task": "You have recently changed your phone number. Write a letter to your friend explaining the situation and your request."
  },
  {
    "id": 91,
    "type": "task1",
    "subtype": "general",
    "task": "You borrowed renewable energy usage from a friend and it got damaged. Write a letter to explain and offer compensation."
  },
  {
    "id": 92,
    "type": "task1",
    "subtype": "general",
    "task": "You borrowed households with Internet access from a friend and it got damaged. Write a letter to explain and offer compensation."
  },
  {
    "id": 93,
    "type": "task1",
    "subtype": "general",
    "task": "You borrowed students enrolled in universities from a friend and it got damaged. Write a letter to explain and offer compensation."
  },
  {
    "id": 94,
    "type": "task1",
    "subtype": "general",
    "task": "You want to organize an event. Write a letter to your your friend giving details and asking for help."
  },
  {
    "id": 95,
    "type": "task1",
    "subtype": "general",
    "task": "You have recently lost your luggage. Write a letter to your manager explaining the situation and your request."
  },
  {
    "id": 96,
    "type": "task1",
    "subtype": "general",
    "task": "You have recently lost your luggage. Write a letter to your manager explaining the situation and your request."
  },
  {
    "id": 97,
    "type": "task1",
    "subtype": "general",
    "task": "You borrowed renewable energy usage from a friend and it got damaged. Write a letter to explain and offer compensation."
  },
  {
    "id": 98,
    "type": "task1",
    "subtype": "general",
    "task": "You want to book a room. Write a letter to your your landlord giving details and asking for help."
  },
  {
    "id": 99,
    "type": "task1",
    "subtype": "general",
    "task": "You borrowed students enrolled in universities from a friend and it got damaged. Write a letter to explain and offer compensation."
  },
  {
    "id": 100,
    "type": "task1",
    "subtype": "general",
    "task": "You have recently changed your phone number. Write a letter to your landlord explaining the situation and your request."
  },
  {
    "id": 101,
    "type": "task2",
    "task": "global warming is becoming a major concern. What are the causes and solutions?"
  },
  {
    "id": 102,
    "type": "task2",
    "task": "Some people believe that unpaid community work should be mandatory for teenagers. To what extent do you agree or disagree?"
  },
  {
    "id": 103,
    "type": "task2",
    "task": "Many believe that social media is harming real-life communication. Do you agree or disagree?"
  },
  {
    "id": 104,
    "type": "task2",
    "task": "global warming is becoming a major concern. What are the causes and solutions?"
  },
  {
    "id": 105,
    "type": "task2",
    "task": "youth unemployment is becoming a major concern. What are the causes and solutions?"
  },
  {
    "id": 106,
    "type": "task2",
    "task": "Some people believe that unpaid community work should be mandatory for teenagers. To what extent do you agree or disagree?"
  },
  {
    "id": 107,
    "type": "task2",
    "task": "Some think that traditional books are better than e-books. Discuss both views and give your opinion."
  },
  {
    "id": 108,
    "type": "task2",
    "task": "Some people believe that public transport should be free. To what extent do you agree or disagree?"
  },
  {
    "id": 109,
    "type": "task2",
    "task": "Many believe that social media is harming real-life communication. Do you agree or disagree?"
  },
  {
    "id": 110,
    "type": "task2",
    "task": "global warming is becoming a major concern. What are the causes and solutions?"
  },
  {
    "id": 111,
    "type": "task2",
    "task": "Some think that traditional books are better than e-books. Discuss both views and give your opinion."
  },
  {
    "id": 112,
    "type": "task2",
    "task": "plastic pollution is becoming a major concern. What are the causes and solutions?"
  },
  {
    "id": 113,
    "type": "task2",
    "task": "In some countries, students take a gap year after high school. Discuss the advantages and disadvantages."
  },
  {
    "id": 114,
    "type": "task2",
    "task": "Many believe that technology makes people less sociable. Do you agree or disagree?"
  },
  {
    "id": 115,
    "type": "task2",
    "task": "In some countries, people work remotely from home. Discuss the advantages and disadvantages."
  },
  {
    "id": 116,
    "type": "task2",
    "task": "Some people believe that public transport should be free. To what extent do you agree or disagree?"
  },
  {
    "id": 117,
    "type": "task2",
    "task": "In some countries, students take a gap year after high school. Discuss the advantages and disadvantages."
  },
  {
    "id": 118,
    "type": "task2",
    "task": "Some people believe that public transport should be free. To what extent do you agree or disagree?"
  },
  {
    "id": 119,
    "type": "task2",
    "task": "Some people believe that public transport should be free. To what extent do you agree or disagree?"
  },
  {
    "id": 120,
    "type": "task2",
    "task": "In some countries, students take a gap year after high school. Discuss the advantages and disadvantages."
  },
  {
    "id": 121,
    "type": "task2",
    "task": "Some think that online learning will replace classroom teaching. Discuss both views and give your opinion."
  },
  {
    "id": 122,
    "type": "task2",
    "task": "In some countries, students take a gap year after high school. Discuss the advantages and disadvantages."
  },
  {
    "id": 123,
    "type": "task2",
    "task": "Many believe that technology makes people less sociable. Do you agree or disagree?"
  },
  {
    "id": 124,
    "type": "task2",
    "task": "Some think that online learning will replace classroom teaching. Discuss both views and give your opinion."
  },
  {
    "id": 125,
    "type": "task2",
    "task": "In some countries, people work remotely from home. Discuss the advantages and disadvantages."
  },
  {
    "id": 126,
    "type": "task2",
    "task": "Many believe that technology makes people less sociable. Do you agree or disagree?"
  },
  {
    "id": 127,
    "type": "task2",
    "task": "Some think that online learning will replace classroom teaching. Discuss both views and give your opinion."
  },
  {
    "id": 128,
    "type": "task2",
    "task": "Many believe that technology makes people less sociable. Do you agree or disagree?"
  },
  {
    "id": 129,
    "type": "task2",
    "task": "In some countries, students take a gap year after high school. Discuss the advantages and disadvantages."
  },
  {
    "id": 130,
    "type": "task2",
    "task": "In some countries, students take a gap year after high school. Discuss the advantages and disadvantages."
  },
  {
    "id": 131,
    "type": "task2",
    "task": "youth unemployment is becoming a major concern. What are the causes and solutions?"
  },
  {
    "id": 132,
    "type": "task2",
    "task": "Some people believe that unpaid community work should be mandatory for teenagers. To what extent do you agree or disagree?"
  },
  {
    "id": 133,
    "type": "task2",
    "task": "Some people believe that unpaid community work should be mandatory for teenagers. To what extent do you agree or disagree?"
  },
  {
    "id": 134,
    "type": "task2",
    "task": "In some countries, people work remotely from home. Discuss the advantages and disadvantages."
  },
  {
    "id": 135,
    "type": "task2",
    "task": "Many believe that social media is harming real-life communication. Do you agree or disagree?"
  },
  {
    "id": 136,
    "type": "task2",
    "task": "Some people believe that public transport should be free. To what extent do you agree or disagree?"
  },
  {
    "id": 137,
    "type": "task2",
    "task": "In some countries, students take a gap year after high school. Discuss the advantages and disadvantages."
  },
  {
    "id": 138,
    "type": "task2",
    "task": "plastic pollution is becoming a major concern. What are the causes and solutions?"
  },
  {
    "id": 139,
    "type": "task2",
    "task": "Some people believe that unpaid community work should be mandatory for teenagers. To what extent do you agree or disagree?"
  },
  {
    "id": 140,
    "type": "task2",
    "task": "Many believe that technology makes people less sociable. Do you agree or disagree?"
  },
  {
    "id": 141,
    "type": "task2",
    "task": "Some think that online learning will replace classroom teaching. Discuss both views and give your opinion."
  },
  {
    "id": 142,
    "type": "task2",
    "task": "In some countries, students take a gap year after high school. Discuss the advantages and disadvantages."
  },
  {
    "id": 143,
    "type": "task2",
    "task": "global warming is becoming a major concern. What are the causes and solutions?"
  },
  {
    "id": 144,
    "type": "task2",
    "task": "Some people believe that unpaid community work should be mandatory for teenagers. To what extent do you agree or disagree?"
  },
  {
    "id": 145,
    "type": "task2",
    "task": "Some think that traditional books are better than e-books. Discuss both views and give your opinion."
  },
  {
    "id": 146,
    "type": "task2",
    "task": "Some people believe that public transport should be free. To what extent do you agree or disagree?"
  },
  {
    "id": 147,
    "type": "task2",
    "task": "Many believe that social media is harming real-life communication. Do you agree or disagree?"
  },
  {
    "id": 148,
    "type": "task2",
    "task": "global warming is becoming a major concern. What are the causes and solutions?"
  },
  {
    "id": 149,
    "type": "task2",
    "task": "Some people believe that unpaid community work should be mandatory for teenagers. To what extent do you agree or disagree?"
  },
  {
    "id": 150,
    "type": "task2",
    "task": "In some countries, students take a gap year after high school. Discuss the advantages and disadvantages."
  },
  {
    "id": 151,
    "type": "task2",
    "task": "Many believe that social media is harming real-life communication. Do you agree or disagree?"
  },
  {
    "id": 152,
    "type": "task2",
    "task": "Some people believe that unpaid community work should be mandatory for teenagers. To what extent do you agree or disagree?"
  },
  {
    "id": 153,
    "type": "task2",
    "task": "Many believe that technology makes people less sociable. Do you agree or disagree?"
  },
  {
    "id": 154,
    "type": "task2",
    "task": "In some countries, students take a gap year after high school. Discuss the advantages and disadvantages."
  },
  {
    "id": 155,
    "type": "task2",
    "task": "plastic pollution is becoming a major concern. What are the causes and solutions?"
  },
  {
    "id": 156,
    "type": "task2",
    "task": "Some think that online learning will replace classroom teaching. Discuss both views and give your opinion."
  },
  {
    "id": 157,
    "type": "task2",
    "task": "Some people believe that unpaid community work should be mandatory for teenagers. To what extent do you agree or disagree?"
  },
  {
    "id": 158,
    "type": "task2",
    "task": "youth unemployment is becoming a major concern. What are the causes and solutions?"
  },
  {
    "id": 159,
    "type": "task2",
    "task": "In some countries, people work remotely from home. Discuss the advantages and disadvantages."
  },
  {
    "id": 160,
    "type": "task2",
    "task": "youth unemployment is becoming a major concern. What are the causes and solutions?"
  },
  {
    "id": 161,
    "type": "task2",
    "task": "Some people believe that unpaid community work should be mandatory for teenagers. To what extent do you agree or disagree?"
  },
  {
    "id": 162,
    "type": "task2",
    "task": "youth unemployment is becoming a major concern. What are the causes and solutions?"
  },
  {
    "id": 163,
    "type": "task2",
    "task": "Many believe that technology makes people less sociable. Do you agree or disagree?"
  },
  {
    "id": 164,
    "type": "task2",
    "task": "Some think that traditional books are better than e-books. Discuss both views and give your opinion."
  },
  {
    "id": 165,
    "type": "task2",
    "task": "Some people believe that unpaid community work should be mandatory for teenagers. To what extent do you agree or disagree?"
  },
  {
    "id": 166,
    "type": "task2",
    "task": "Some people believe that public transport should be free. To what extent do you agree or disagree?"
  },
  {
    "id": 167,
    "type": "task2",
    "task": "Many believe that social media is harming real-life communication. Do you agree or disagree?"
  },
  {
    "id": 168,
    "type": "task2",
    "task": "In some countries, people work remotely from home. Discuss the advantages and disadvantages."
  },
  {
    "id": 169,
    "type": "task2",
    "task": "Many believe that technology makes people less sociable. Do you agree or disagree?"
  },
  {
    "id": 170,
    "type": "task2",
    "task": "Many believe that social media is harming real-life communication. Do you agree or disagree?"
  },
  {
    "id": 171,
    "type": "task2",
    "task": "global warming is becoming a major concern. What are the causes and solutions?"
  },
  {
    "id": 172,
    "type": "task2",
    "task": "Many believe that technology makes people less sociable. Do you agree or disagree?"
  },
  {
    "id": 173,
    "type": "task2",
    "task": "In some countries, students take a gap year after high school. Discuss the advantages and disadvantages."
  },
  {
    "id": 174,
    "type": "task2",
    "task": "In some countries, people work remotely from home. Discuss the advantages and disadvantages."
  },
  {
    "id": 175,
    "type": "task2",
    "task": "Some think that traditional books are better than e-books. Discuss both views and give your opinion."
  },
  {
    "id": 176,
    "type": "task2",
    "task": "Many believe that technology makes people less sociable. Do you agree or disagree?"
  },
  {
    "id": 177,
    "type": "task2",
    "task": "Some think that online learning will replace classroom teaching. Discuss both views and give your opinion."
  },
  {
    "id": 178,
    "type": "task2",
    "task": "Some people believe that unpaid community work should be mandatory for teenagers. To what extent do you agree or disagree?"
  },
  {
    "id": 179,
    "type": "task2",
    "task": "In some countries, people work remotely from home. Discuss the advantages and disadvantages."
  },
  {
    "id": 180,
    "type": "task2",
    "task": "youth unemployment is becoming a major concern. What are the causes and solutions?"
  },
  {
    "id": 181,
    "type": "task2",
    "task": "In some countries, people work remotely from home. Discuss the advantages and disadvantages."
  },
  {
    "id": 182,
    "type": "task2",
    "task": "Many believe that social media is harming real-life communication. Do you agree or disagree?"
  },
  {
    "id": 183,
    "type": "task2",
    "task": "global warming is becoming a major concern. What are the causes and solutions?"
  },
  {
    "id": 184,
    "type": "task2",
    "task": "Many believe that technology makes people less sociable. Do you agree or disagree?"
  },
  {
    "id": 185,
    "type": "task2",
    "task": "In some countries, people work remotely from home. Discuss the advantages and disadvantages."
  },
  {
    "id": 186,
    "type": "task2",
    "task": "Many believe that social media is harming real-life communication. Do you agree or disagree?"
  },
  {
    "id": 187,
    "type": "task2",
    "task": "In some countries, students take a gap year after high school. Discuss the advantages and disadvantages."
  },
  {
    "id": 188,
    "type": "task2",
    "task": "Some think that traditional books are better than e-books. Discuss both views and give your opinion."
  },
  {
    "id": 189,
    "type": "task2",
    "task": "In some countries, people work remotely from home. Discuss the advantages and disadvantages."
  },
  {
    "id": 190,
    "type": "task2",
    "task": "plastic pollution is becoming a major concern. What are the causes and solutions?"
  },
  {
    "id": 191,
    "type": "task2",
    "task": "Some think that traditional books are better than e-books. Discuss both views and give your opinion."
  },
  {
    "id": 192,
    "type": "task2",
    "task": "Some think that online learning will replace classroom teaching. Discuss both views and give your opinion."
  },
  {
    "id": 193,
    "type": "task2",
    "task": "Some think that traditional books are better than e-books. Discuss both views and give your opinion."
  },
  {
    "id": 194,
    "type": "task2",
    "task": "Many believe that social media is harming real-life communication. Do you agree or disagree?"
  },
  {
    "id": 195,
    "type": "task2",
    "task": "Some people believe that unpaid community work should be mandatory for teenagers. To what extent do you agree or disagree?"
  },
  {
    "id": 196,
    "type": "task2",
    "task": "In some countries, people work remotely from home. Discuss the advantages and disadvantages."
  },
  {
    "id": 197,
    "type": "task2",
    "task": "Some think that traditional books are better than e-books. Discuss both views and give your opinion."
  },
  {
    "id": 198,
    "type": "task2",
    "task": "In some countries, students take a gap year after high school. Discuss the advantages and disadvantages."
  },
  {
    "id": 199,
    "type": "task2",
    "task": "Some think that online learning will replace classroom teaching. Discuss both views and give your opinion."
  },
  {
    "id": 200,
    "type": "task2",
    "task": "Many believe that social media is harming real-life communication. Do you agree or disagree?"
  }
];
