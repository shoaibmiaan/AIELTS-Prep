// src/lib/listeningTests.ts

// ✅ This list must match exactly the filenames in /src/data/listening-tests
export const listeningTestIds = [
  'test01',
  'test02',
  'test03',
];
