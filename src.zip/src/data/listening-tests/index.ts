// src/data/listening-tests/index.ts
import test01 from './test01.json';
import test02 from './test02.json';
import test03 from './test03.json';

export const listeningTests = [test01, test02, test03];
