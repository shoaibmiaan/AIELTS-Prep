'use client';
import React, { useState, useEffect, FormEvent } from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';
import { useAuth } from '@/context/AuthContext';
import toast from 'react-hot-toast';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { colors } from '@/styles/theme';

export default function LoginPage() {
  const router = useRouter();
  const { login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [darkMode, setDarkMode] = useState(true);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isPremium, setIsPremium] = useState(false);
  const [currentPage, setCurrentPage] = useState('');

  // Initialize login, premium state, and dark mode
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const savedLogin = localStorage.getItem('isLoggedIn');
      const savedPremium = localStorage.getItem('isPremium');
      const savedMode = localStorage.getItem('darkMode');
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;

      if (savedLogin === 'true') {
        setIsLoggedIn(true);
      }

      if (savedPremium === 'true') {
        setIsPremium(true);
      }

      if (savedMode === 'true' || (!savedMode && prefersDark)) {
        setDarkMode(true);
        document.documentElement.classList.add('dark');
      } else {
        setDarkMode(false);
        document.documentElement.classList.remove('dark');
      }
    }
  }, []);

  const toggleDarkMode = () => {
    const newMode = !darkMode;
    setDarkMode(newMode);
    if (typeof window !== 'undefined') {
      localStorage.setItem('darkMode', String(newMode));
      document.documentElement.classList.toggle('dark', newMode);
    }
  };

  const handleNavigation = (route: string) => {
    if (route.startsWith('http')) {
      window.open(route, '_blank');
      return;
    }
    if (route === '/logout') {
      setIsLoggedIn(false);
      setIsPremium(false);
      if (typeof window !== 'undefined') {
        localStorage.removeItem('isLoggedIn');
        localStorage.removeItem('isPremium');
      }
      router.push('/');
      return;
    }
    router.push(route);
  };

  const handleProtectedClick = (route: string) => {
    setCurrentPage(route);
    if (!isLoggedIn) {
      if (typeof window !== 'undefined') {
        sessionStorage.setItem('redirectUrl', route);
      }
      router.push('/login');
    } else {
      router.push(route);
    }
  };

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      await login(email, password);
      toast.success('Logged in successfully!');
      setIsLoggedIn(true);
      if (typeof window !== 'undefined') {
        localStorage.setItem('isLoggedIn', 'true');
      }

      const returnUrl = typeof window !== 'undefined' ? sessionStorage.getItem('redirectUrl') || '/dashboard' : '/dashboard';
      if (typeof window !== 'undefined') {
        sessionStorage.removeItem('redirectUrl');
      }
      await router.push(returnUrl);
    } catch (error: any) {
      setError(error.message || 'Invalid credentials. Please try again.');
      toast.error(error.message || 'Invalid credentials. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={`font-sans min-h-screen flex flex-col transition-colors duration-300 bg-${colors.backgroundLight} dark:bg-${colors.backgroundDark}`}>
      <Header
        isLoggedIn={isLoggedIn}
        isPremium={isPremium}
        darkMode={darkMode}
        toggleDarkMode={toggleDarkMode}
        handleNavigation={handleNavigation}
        handleProtectedClick={handleProtectedClick}
      />

      <main className="flex-grow flex items-center justify-center px-6 py-12">
        <div className="w-full max-w-md bg-gray-100 dark:bg-gray-800 rounded-xl shadow-xl p-8 sm:p-10">
          <h2 className="text-3xl font-bold text-center mb-4 dark:text-gray-300 text-gray-800">Welcome Back</h2>
          <p className="text-center text-sm mb-8 text-gray-600 dark:text-gray-400">
            Log in to your account to continue
          </p>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="email" className="block text-sm font-medium mb-1 text-gray-700 dark:text-gray-300">
                Email Address
              </label>
              <input
                id="email"
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className={`w-full px-4 py-3 rounded-xl border border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-400 transition ${
                  darkMode ? 'bg-gray-700 text-gray-300' : 'bg-gray-100 text-gray-800'
                }`}
                disabled={loading}
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium mb-1 text-gray-700 dark:text-gray-300">
                Password
              </label>
              <input
                id="password"
                type="password"
                autoComplete="current-password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className={`w-full px-4 py-3 rounded-xl border border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-400 transition ${
                  darkMode ? 'bg-gray-700 text-gray-300' : 'bg-gray-100 text-gray-800'
                }`}
                disabled={loading}
              />
            </div>

            {error && <p className="text-red-500 text-sm text-center">{error}</p>}

            <button
              type="submit"
              disabled={loading}
              className={`w-full py-3 px-4 rounded-xl font-semibold text-gray-800 bg-blue-600 hover:bg-blue-700 transition disabled:opacity-50 disabled:cursor-not-allowed`}
            >
              {loading ? 'Logging in...' : 'Log In'}
            </button>

            <div className="flex justify-between text-sm mt-4">
              <Link href="/forgot-password" className="text-blue-400 hover:text-blue-700 dark:hover:text-blue-200">
                Forgot password?
              </Link>
              <Link href="/signup" className="text-blue-400 hover:text-blue-700 dark:hover:text-blue-200">
                Sign Up
              </Link>
            </div>
          </form>
        </div>
      </main>

      <Footer
        handleNavigation={handleNavigation}
        handleProtectedClick={handleProtectedClick}
      />

      <style jsx global>{`
        html {
          transition: background-color 0.3s ease;
        }
        body {
          transition: background-color 0.3s ease;
        }
      `}</style>
    </div>
  );
}
