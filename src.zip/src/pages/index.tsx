'use client';
import { useState, useEffect } from 'react';
import Head from 'next/head';
import { useRouter } from 'next/router';
import { useAuth } from '@/context/AuthContext';
import toast from 'react-hot-toast';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import HomeContent from '@/components/home/HomeContent';
import GuestContent from '@/components/home/GuestContent';
import LoginModal from '@/components/home/LoginModal';
import { colors, fontSizes, spacing } from '@/styles/theme';

interface UserProgress {
  writing: number;
  listening: number;
  speaking: number;
  reading: number;
  overall: number;
  targetBand: number;
}

interface StudyPlanItem {
  id: number;
  title: string;
  module: string;
  duration: string;
  progress: number;
  locked: boolean;
}

interface Activity {
  id: number;
  type: string;
  title: string;
  score: number;
  date: string;
  improvement: string;
}

interface WritingSample {
  id: number;
  task: string;
  band: number;
  date: string;
  wordCount: number;
  feedback: boolean;
}

interface CommunityPost {
  id: number;
  title: string;
  comments: number;
  author: string;
  time: string;
}

interface MockTest {
  id: number;
  type: string;
  date: string;
  score: number;
  timeSpent: string;
}

export default function IELTSMaster() {
  const router = useRouter();
  const { user, profile } = useAuth();

  // UI State
  const [darkMode, setDarkMode] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [currentPage, setCurrentPage] = useState('');
  const [activeTab, setActiveTab] = useState('');

  // Form State
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  // User Data State
  const [userProgress, setUserProgress] = useState<UserProgress>({
    writing: user ? 65 : 30,
    listening: user ? 45 : 0,
    speaking: user ? 30 : 0,
    reading: user ? 70 : 45,
    overall: user ? 6.5 : 5.0,
    targetBand: profile?.target_band || 6.0
  });

  const [studyPlan, setStudyPlan] = useState<StudyPlanItem[]>([
    { id: 1, title: 'Complex Sentences', module: 'Writing', duration: '25 min', progress: user ? 65 : 30, locked: false },
    { id: 2, title: 'Map Labelling', module: 'Listening', duration: '35 min', progress: user ? 45 : 0, locked: !user },
    { id: 3, title: 'Part 3 Strategies', module: 'Speaking', duration: '45 min', progress: user ? 30 : 0, locked: false },
    { id: 4, title: 'True/False/Not Given', module: 'Reading', duration: '40 min', progress: 0, locked: true }
  ]);

  const [recentActivities, setRecentActivities] = useState<Activity[]>(
    user ? [
      { id: 1, type: 'writing', title: 'Writing Task 2 Evaluation', score: 6.0, date: '2 hours ago', improvement: '+0.5 from last' },
      { id: 2, type: 'mock', title: 'Full Mock Test', score: 6.5, date: '1 day ago', improvement: '+1.0 from last' },
      { id: 3, type: 'speaking', title: 'Speaking Part 2 Practice', score: 5.5, date: '3 days ago', improvement: '+0.5 from last' }
    ] : []
  );

  const [writingSamples, setWritingSamples] = useState<WritingSample[]>(
    user ? [
      { id: 1, task: 'Task 2 - Opinion Essay', band: 6.0, date: 'Jul 15', wordCount: 271, feedback: true },
      { id: 2, task: 'Task 1 - Line Graph', band: 6.5, date: 'Jul 10', wordCount: 187, feedback: true },
      { id: 3, task: 'Task 2 - Discussion Essay', band: 5.5, date: 'Jul 5', wordCount: 243, feedback: false }
    ] : []
  );

  const [communityPosts, setCommunityPosts] = useState<CommunityPost[]>([
    { id: 1, title: 'How to improve speaking fluency quickly?', comments: 42, author: 'Rajesh', time: '2 hours ago' },
    { id: 2, title: 'Writing Task 2 sample answer review', comments: 18, author: 'Maria', time: '5 hours ago' },
    { id: 3, title: 'Listening section 3 strategies', comments: 7, author: 'Ahmed', time: '1 day ago' }
  ]);

  const [mockTests, setMockTests] = useState<MockTest[]>(
    user ? [
      { id: 1, type: 'Full Test', date: 'Jul 16', score: 6.5, timeSpent: '2h 45m' },
      { id: 2, type: 'Reading Only', date: 'Jul 12', score: 7.0, timeSpent: '1h 05m' },
      { id: 3, type: 'Listening Only', date: 'Jul 8', score: 6.5, timeSpent: '40m' }
    ] : []
  );

  // Initialize dark mode
  useEffect(() => {
    const savedMode = localStorage.getItem('darkMode');
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const initialMode = savedMode === 'true' || (!savedMode && prefersDark);
    setDarkMode(initialMode);
    document.documentElement.classList.toggle('dark', initialMode);
  }, []);

  // Toggle dark mode
  const toggleDarkMode = () => {
    const newMode = !darkMode;
    setDarkMode(newMode);
    localStorage.setItem('darkMode', String(newMode));
    document.documentElement.classList.toggle('dark', newMode);
  };

  // Navigation Handlers
  const handleNavigation = (route: string) => {
    if (route.startsWith('http')) {
      window.open(route, '_blank');
      return;
    }
    if (route === '/logout') {
      logout();
      return;
    }
    router.push(route);
  };

  const handleProtectedClick = (route: string) => {
    setCurrentPage(route);
    if (!user) {
      sessionStorage.setItem('redirectUrl', route);
      setShowLoginModal(true);
    } else {
      router.push(route);
    }
  };

  const navigateTo = (route: string) => {
    setActiveTab(route);
    router.push(route);
  };

  // Feature Handlers
  const startMockTest = () => handleProtectedClick('/mock-test/start');
  const analyzeWriting = () => handleProtectedClick('/writing-evaluator');
  const startSpeakingPractice = () => handleProtectedClick('/speaking-simulator');
  const accessPremiumDashboard = () => handleProtectedClick('/premium-dashboard');

  const continueLesson = (id: number) => {
    const lesson = studyPlan.find(l => l.id === id);
    if (lesson && !lesson.locked) {
      router.push(`/lessons/${id}`);
    } else {
      toast.error('This lesson is locked');
    }
  };

  const viewWritingFeedback = (id: number) => handleProtectedClick(`/writing-feedback/${id}`);

  // Update target band
  const updateTargetBand = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newTarget = parseFloat(e.target.value);
    setUserProgress(prev => ({
      ...prev,
      targetBand: newTarget
    }));
    toast.success(`Target band updated to ${newTarget}`);
  };

  // Auth Handlers
  const handleLogin = async () => {
    try {
      await login(email, password);
      setShowLoginModal(false);
      const redirectUrl = sessionStorage.getItem('redirectUrl') || '/';
      sessionStorage.removeItem('redirectUrl');
      await router.push(redirectUrl);
    } catch (error) {
      toast.error('Invalid credentials. Please try again.');
    }
  };

  const handleFreePlan = () => {
    setShowLoginModal(false);
    router.push(currentPage || '/');
  };

  return (
    <div className={`font-sans bg-gray-50 dark:bg-gray-900 min-h-screen transition-colors duration-300`}>
      <Head>
        <title>{user ? 'Home | IELTS Master' : 'IELTS Master - AI-Powered Preparation'}</title>
        <meta name="description" content="Improve your IELTS score with AI-powered tools and personalized feedback" />
        <link rel="icon" href="/favicon.ico" />
        <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
      </Head>

      <Header
        darkMode={darkMode}
        toggleDarkMode={toggleDarkMode}
        activeTab={activeTab}
        navigateTo={navigateTo}
        handleProtectedClick={handleProtectedClick}
        handleNavigation={handleNavigation}
        user={user}
        profile={profile}
      />

      <main className="container mx-auto px-6 py-10">
        {user ? (
          <HomeContent
            userProgress={userProgress}
            studyPlan={studyPlan}
            recentActivities={recentActivities}
            writingSamples={writingSamples}
            communityPosts={communityPosts}
            mockTests={mockTests}
            darkMode={darkMode}
            navigateTo={navigateTo}
            startMockTest={startMockTest}
            analyzeWriting={analyzeWriting}
            startSpeakingPractice={startSpeakingPractice}
            continueLesson={continueLesson}
            viewWritingFeedback={viewWritingFeedback}
            updateTargetBand={updateTargetBand}
            isPremium={profile?.is_premium || false}
          />
        ) : (
          <GuestContent
            startMockTest={startMockTest}
            handleProtectedClick={handleProtectedClick}
            accessPremiumDashboard={accessPremiumDashboard}
            userProgress={userProgress}
          />
        )}
      </main>

      <LoginModal
        showLoginModal={showLoginModal}
        setShowLoginModal={setShowLoginModal}
        email={email}
        setEmail={setEmail}
        password={password}
        setPassword={setPassword}
        handleLogin={handleLogin}
        handleFreePlan={handleFreePlan}
        darkMode={darkMode}
      />

      <Footer
        handleNavigation={handleNavigation}
        handleProtectedClick={handleProtectedClick}
      />

      <style jsx global>{`
        html {
          transition: background-color 0.3s ease;
        }
        body {
          transition: background-color 0.3s ease;
        }
      `}</style>
    </div>
  );
}