export default function SpeakingHistoryPage() {
  return (
    <div className="p-6">
      <h1 className="text-xl font-bold">Speaking History</h1>
      <p>This page will show the speaking session history. Coming soon!</p>
    </div>
  );
}
