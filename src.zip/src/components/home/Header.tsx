'use client';
import { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/context/AuthContext';
import { useTheme } from '@/components/ThemeContext';

interface HeaderProps {
  darkMode: boolean;
  toggleDarkMode: () => void;
  activeTab: string;
  navigateTo: (route: string) => void;
  handleProtectedClick: (route: string) => void;
  handleNavigation: (route?: string) => void; // Made route optional
}

export default function Header({
  darkMode,
  toggleDarkMode,
  activeTab,
  navigateTo,
  handleProtectedClick,
  handleNavigation
}: HeaderProps) {
  const router = useRouter();
  const { user, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Safe navigation handler
  const safeHandleNavigation = (route?: string) => {
    if (!route) return;
    handleNavigation(route);
  };

  // Safe active tab check
  const isActiveTab = (tabPath: string) => {
    return activeTab?.startsWith?.(tabPath) ?? false;
  };

  return (
    <header className="sticky top-0 z-50 shadow-md">
      <div className="container mx-auto px-6 py-3 flex justify-between items-center">
        <div
          className="flex items-center space-x-2 cursor-pointer"
          onClick={() => safeHandleNavigation('/')}
        >
          <i className="fas fa-book-open text-yellow-600 text-2xl"></i>
          <span className="text-xl font-bold">IELTSMaster</span>
        </div>

        <nav className="hidden md:flex space-x-8">
          {user ? (
            <>
              <div className="dropdown relative" ref={dropdownRef}>
                <button
                  className={`${
                    isActiveTab('learn') ? 'text-yellow-600' : 'text-gray-700'
                  } hover:text-yellow-600 font-medium`}
                  onClick={() => setDropdownOpen(!dropdownOpen)}
                >
                  Learn <i className="fas fa-chevron-down ml-1 text-xs"></i>
                </button>
                <div className={`dropdown-menu absolute ${dropdownOpen ? 'block' : 'hidden'} bg-white shadow-lg rounded-md mt-2 w-48`}>
                  <button
                    onClick={() => navigateTo('/courses')}
                    className="block px-4 py-2 hover:bg-yellow-50 text-left w-full"
                  >
                    Courses
                  </button>
                  <button
                    onClick={() => navigateTo('/grammar')}
                    className="block px-4 py-2 hover:bg-yellow-50 text-left w-full"
                  >
                    Grammar/Vocabulary
                  </button>
                  <button
                    onClick={() => navigateTo('/strategies')}
                    className="block px-4 py-2 hover:bg-yellow-50 text-left w-full"
                  >
                    Strategies
                  </button>
                </div>
              </div>
              <button
                className={`${
                  activeTab === 'assessmentRoom' ? 'text-yellow-600' : 'text-gray-700'
                } hover:text-yellow-600 font-medium`}
                onClick={() => navigateTo('/assessmentRoom')}
              >
                assessmentRoom
              </button>
              <button
                className={`${
                  activeTab === 'ai-tools' ? 'text-yellow-600' : 'text-gray-700'
                } hover:text-yellow-600 font-medium`}
                onClick={() => navigateTo('/ai-tools')}
              >
                AI Tools
              </button>
              <button
                className={`${
                  activeTab === 'community' ? 'text-yellow-600' : 'text-gray-700'
                } hover:text-yellow-600 font-medium`}
                onClick={() => navigateTo('/community')}
              >
                Community
              </button>
              <button
                className={`${
                  activeTab === 'progress' ? 'text-yellow-600' : 'text-gray-700'
                } hover:text-yellow-600 font-medium`}
                onClick={() => navigateTo('/progress')}
              >
                Progress
              </button>
            </>
          ) : (
            <>
              <div className="dropdown relative" ref={dropdownRef}>
                <button
                  className="text-gray-700 hover:text-yellow-600 font-medium"
                  onClick={() => setDropdownOpen(!dropdownOpen)}
                >
                  Learn <i className="fas fa-chevron-down ml-1 text-xs"></i>
                </button>
                <div className={`dropdown-menu absolute ${dropdownOpen ? 'block' : 'hidden'} bg-white shadow-lg rounded-md mt-2 w-48`}>
                  <button
                    onClick={(e) => {
                      e.preventDefault();
                      handleProtectedClick('/courses');
                    }}
                    className="block px-4 py-2 hover:bg-yellow-50 text-left w-full"
                  >
                    Courses
                  </button>
                  <button
                    onClick={(e) => {
                      e.preventDefault();
                      handleProtectedClick('/grammar');
                    }}
                    className="block px-4 py-2 hover:bg-yellow-50 text-left w-full"
                  >
                    Grammar/Vocabulary
                  </button>
                  <button
                    onClick={(e) => {
                      e.preventDefault();
                      handleProtectedClick('/strategies');
                    }}
                    className="block px-4 py-2 hover:bg-yellow-50 text-left w-full"
                  >
                    Strategies
                  </button>
                </div>
              </div>
              <button
                onClick={(e) => {
                  e.preventDefault();
                  handleProtectedClick('/assessmentRoom');
                }}
                className="text-gray-700 hover:text-yellow-600 font-medium"
              >
                assessmentRoom
              </button>
              <button
                onClick={(e) => {
                  e.preventDefault();
                  handleProtectedClick('/ai-tools');
                }}
                className="text-gray-700 hover:text-yellow-600 font-medium"
              >
                AI Tools
              </button>
              <button
                onClick={(e) => {
                  e.preventDefault();
                  handleProtectedClick('/community');
                }}
                className="text-gray-700 hover:text-yellow-600 font-medium"
              >
                Community
              </button>
              <button
                onClick={() => safeHandleNavigation('/pricing')}
                className="text-gray-700 hover:text-yellow-600 font-medium"
              >
                Pricing
              </button>
            </>
          )}
        </nav>

        <div className="flex items-center space-x-4">
          <button
            onClick={toggleDarkMode}
            className="p-2 rounded-full bg-gray-100 text-gray-600"
            aria-label="Toggle dark mode"
          >
            {darkMode ? <i className="fas fa-sun"></i> : <i className="fas fa-moon"></i>}
          </button>

          {user ? (
            <div className="dropdown relative" ref={dropdownRef}>
              <button
                className="flex items-center space-x-2 p-2 rounded-full bg-gray-100 text-gray-600"
                onClick={() => setDropdownOpen(!dropdownOpen)}
                aria-label="User profile"
              >
                <span className="w-8 h-8 rounded-full bg-yellow-500 flex items-center justify-center text-white font-medium">
                  {user?.email?.charAt(0).toUpperCase()}
                </span>
                <i className="fas fa-chevron-down text-xs"></i>
              </button>
              <div className={`dropdown-menu absolute ${dropdownOpen ? 'block' : 'hidden'} right-0 mt-2 w-48 bg-white shadow-lg rounded-md`}>
                <div className="px-4 py-3 border-b">
                  <p className="text-sm font-medium">{user?.email}</p>
                  <p className="text-xs text-gray-500">Premium Member</p>
                </div>
                <button
                  className="block px-4 py-2 text-sm hover:bg-gray-100 text-left w-full"
                  onClick={() => navigateTo('/profile')}
                >
                  <i className="fas fa-user mr-2"></i> Profile
                </button>
                <button
                  className="block px-4 py-2 text-sm hover:bg-gray-100 text-left w-full"
                  onClick={() => navigateTo('/settings')}
                >
                  <i className="fas fa-cog mr-2"></i> Settings
                </button>
                <button
                  className="block px-4 py-2 text-sm hover:bg-gray-100 text-left w-full"
                  onClick={logout}
                >
                  <i className="fas fa-sign-out-alt mr-2"></i> Sign out
                </button>
              </div>
            </div>
          ) : (
            <button
              className="p-2 rounded-full bg-gray-100 text-gray-600"
              onClick={() => safeHandleNavigation('/login')}
              aria-label="Login"
            >
              <i className="fas fa-user"></i>
            </button>
          )}

          {!user && (
            <button
              className="bg-yellow-600 hover:bg-yellow-700 text-white px-4 py-2 rounded-md font-medium"
              onClick={() => safeHandleNavigation('/pricing')}
            >
              Go Premium
            </button>
          )}

          <button
            className="md:hidden text-gray-600"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Mobile menu"
          >
            <i className="fas fa-bars text-xl"></i>
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <div className={`${mobileMenuOpen ? 'block' : 'hidden'} md:hidden bg-white border-t`}>
        <div className="container mx-auto px-6 py-3 flex flex-col space-y-3">
          {user ? (
            <>
              <button
                className={`py-2 border-b ${isActiveTab('dashboard') ? 'text-yellow-600' : 'text-gray-700'}`}
                onClick={() => {
                  navigateTo('/dashboard');
                  setMobileMenuOpen(false);
                }}
              >
                Dashboard
              </button>
              <button
                className={`py-2 border-b ${isActiveTab('learn') ? 'text-yellow-600' : 'text-gray-700'}`}
                onClick={() => {
                  navigateTo('/courses');
                  setMobileMenuOpen(false);
                }}
              >
                Learn
              </button>
              <button
                className={`py-2 border-b ${activeTab === 'assessmentRoom' ? 'text-yellow-600' : 'text-gray-700'}`}
                onClick={() => {
                  navigateTo('/assessmentRoom');
                  setMobileMenuOpen(false);
                }}
              >
                assessmentRoom
              </button>
              <button
                className={`py-2 border-b ${activeTab === 'ai-tools' ? 'text-yellow-600' : 'text-gray-700'}`}
                onClick={() => {
                  navigateTo('/ai-tools');
                  setMobileMenuOpen(false);
                }}
              >
                AI Tools
              </button>
              <button
                className={`py-2 border-b ${activeTab === 'community' ? 'text-yellow-600' : 'text-gray-700'}`}
                onClick={() => {
                  navigateTo('/community');
                  setMobileMenuOpen(false);
                }}
              >
                Community
              </button>
              <button
                className={`py-2 border-b ${activeTab === 'progress' ? 'text-yellow-600' : 'text-gray-700'}`}
                onClick={() => {
                  navigateTo('/progress');
                  setMobileMenuOpen(false);
                }}
              >
                Progress
              </button>
              <button
                className="py-2 border-b text-red-500"
                onClick={logout}
              >
                Sign Out
              </button>
            </>
          ) : (
            <>
              <button
                onClick={(e) => {
                  e.preventDefault();
                  handleProtectedClick('/courses');
                  setMobileMenuOpen(false);
                }}
                className="py-2 border-b text-gray-700"
              >
                Learn
              </button>
              <button
                onClick={(e) => {
                  e.preventDefault();
                  handleProtectedClick('/assessmentRoom');
                  setMobileMenuOpen(false);
                }}
                className="py-2 border-b text-gray-700"
              >
                assessmentRoom
              </button>
              <button
                onClick={(e) => {
                  e.preventDefault();
                  handleProtectedClick('/ai-tools');
                  setMobileMenuOpen(false);
                }}
                className="py-2 border-b text-gray-700"
              >
                AI Tools
              </button>
              <button
                onClick={(e) => {
                  e.preventDefault();
                  handleProtectedClick('/community');
                  setMobileMenuOpen(false);
                }}
                className="py-2 border-b text-gray-700"
              >
                Community
              </button>
              <button
                onClick={() => {
                  safeHandleNavigation('/pricing');
                  setMobileMenuOpen(false);
                }}
                className="py-2 border-b text-gray-700"
              >
                Pricing
              </button>
              <button
                onClick={() => {
                  safeHandleNavigation('/login');
                  setMobileMenuOpen(false);
                }}
                className="py-2 text-yellow-600"
              >
                Login
              </button>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
