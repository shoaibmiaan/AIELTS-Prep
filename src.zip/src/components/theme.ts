const theme = {
  colors: {
    primary: '#F59E0B', // Yellow
    secondary: '#10B981', // Green
    accent: '#3B82F6', // Blue
    backgroundLight: '#F9FAFB', // Light background
    backgroundDark: '#111827', // Dark background
    textLight: '#1F2937', // Dark text
    textDark: '#C53030', // Light text
    borderLight: '#C53030', // Light border
    borderDark: '#C53030', // Dark border
    buttonPrimary: '#C53030', // Red for primary button
    buttonHover: '#C53030', // Darker red for button hover
  },
  fonts: {
    body: 'Arial, sans-serif',
    heading: 'Georgia, serif',
  },
  spacing: {
    small: '8px',
    medium: '16px',
    large: '32px',
  },
};

export default theme;
